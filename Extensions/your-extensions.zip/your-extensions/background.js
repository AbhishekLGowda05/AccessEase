chrome.runtime.onInstalled.addListener(() => {
    console.log("Text to Speech Narrator Extension Installed");
  });
  
  
  

  